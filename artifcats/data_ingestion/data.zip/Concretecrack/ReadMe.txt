The original dataset is 
called CODEBRIM.

This is a subset of that dataset.

Orginal Dataset Link:
https://zenodo.org/records/2620293